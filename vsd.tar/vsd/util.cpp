#include "util.h"
#include <time.h>

_VCMConfig vcmConf;
_VHLConfig vhlConf;

_SYSTEMTIME get_sys_time()
{
	time_t timer;
	struct tm *t;
	_SYSTEMTIME dateTime;

	timer = time(NULL);
	t = localtime(&timer);

	dateTime.wYear = t->tm_year + 1900;
	dateTime.wMonth = t->tm_mon + 1;
	dateTime.wDayOfWeek = t->tm_wday + 1;
	dateTime.wDay = t->tm_mday;
	dateTime.wHour = t->tm_hour;
	dateTime.wMinute = t->tm_min;
	dateTime.wSecond = t->tm_sec;
	dateTime.wMilliseconds = 0;

	return dateTime;
}

long getTick()
{
    //timeval tick;
    //gettimeofday (&tick, NULL);
    //return (tick.tv_sec+ tick.tv_usec/1000000);
	struct timespec tspec;

	if (clock_gettime(CLOCK_MONOTONIC, &tspec) == -1) {  
		/* 에러 처리*/
	}

	return tspec.tv_sec;
}

void myprintf( uint8_t _nloglevel, bool debug, const char* _szfmt, ... )
{
	const char *color_codes[] = {"\033[1;34m", "\033[1;31m", "\033[1;33m", "\033[1;32m", "\033[0m"};
	va_list va;

	if(!debug) return;
	
	//if(_nloglevel > debug_level) return;

	_SYSTEMTIME saveTime = get_sys_time();

	va_start( va, _szfmt );

	if(_nloglevel <= LOG_LEVEL_TRA) {
		char strTmp[512]; 
		char strTmp2[512]; 
		
		sprintf(strTmp, "echo \"%s[VSD]%04d/%02d/%02d %02d:%02d:%02d\033[0m ", color_codes[_nloglevel], saveTime.wYear
															, saveTime.wMonth
															, saveTime.wDay
															, saveTime.wHour
															, saveTime.wMinute
															, saveTime.wSecond
															);
		vsprintf(strTmp2, _szfmt ,va);
		strcat(strTmp, strTmp2);
		strcat(strTmp, "\" >> /var/log/testlog");
		system(strTmp);
	}

	if(_nloglevel > vcmConf.debug_level) {
		va_end( va );
		return;
	}

	printf("%s[VCM]%04d/%02d/%02d %02d:%02d:%02d\033[0m ", color_codes[_nloglevel], saveTime.wYear
														, saveTime.wMonth
														, saveTime.wDay
														, saveTime.wHour
														, saveTime.wMinute
														, saveTime.wSecond
														);

	
	vprintf( _szfmt, va );
	va_end( va );
	fflush(stdout);

}
