#ifndef _UTIL_H_
#define _UTIL_H_

#include <cstdio>
#include <unistd.h>

#include <termio.h>
#include <stdio.h>
#include <stdint.h>
#include <unistd.h>
#include <cstring>
#include <time.h>
#include <stdlib.h>
#include <stdarg.h>
#include <pthread.h>

#include <arpa/inet.h>
#include <json-c/json.h>

#define SW_VERSION   "1.3"
#define MY_DEBUG  1
#define SRT_ALWAYS

#define LOG_LEVEL_EMG 			0
#define LOG_LEVEL_CRI 			1
#define LOG_LEVEL_TRA 			2
#define LOG_LEVEL_DBG 			3
#define LOG_LEVEL_MSG 			4

#define JSON_FILE   "/root/shared_v/edgeconf_pim.json"
#define JSON_HEADER_VHL "VHL_CAM"
#define JSON_HEADER_NET	"NETWORK"
#define JSON_HEADER_VCM "VCM"

enum MSG_TYPE {
  PMSG_TYPE_UNUSED = 0,
  PMSG_TYPE_IPC,
  PMSG_TYPE_OVERLAY,
  PMSG_TYPE_OSS
};

enum _EVENT_TYPE {
	EVT_NULL = 0,
	EVT_COPY,
	EVT_PRI
};

enum _COMMAND_TAG {
	CMD_STATUSINFO_BLACKBOX = 41001,
	CMD_TIMESETTING_BLACKBOX,
	CMD_TIMESETTING_BLACKBOX_RESPONSE,
	CMD_EVENTREQ_BLACKBOX,
	CMD_EVENTACK_BLACKBOX,
	CMD_ERROR_BLACKBOX
};

union _SYSTEMTIME {
  uint8_t byte[16];
  struct {
    uint16_t wYear;
    uint16_t wMonth;
    uint16_t wDayOfWeek;
    uint16_t wDay;
    uint16_t wHour;
    uint16_t wMinute;
    uint16_t wSecond;
    uint16_t wMilliseconds;
  };
} ;

#pragma pack(push, 1)
struct _OVERLAY {
	uint8_t curMode:8;
	uint8_t curStatus:8;
	uint32_t curNodeID:32;
	uint32_t tagetNodeID:32;
	int curNodeOffset:32;
	double drivingSpeed;
	int eout:32;
	char loutSign:8;
	int lout:32;
	float fAxis1Torque;
	float fAxis2Torque;
	int error:32;
	uint8_t ohtDetectLevel:8;
	uint8_t obsDetectLevel:8;
};

union _OHTDATA {
    char byte[55];
	struct {
		uint16_t machineType;
		uint8_t machineID[6];
		uint16_t cmd;
		union {
			_OVERLAY ov;
			struct {
				uint8_t eventType;
				uint8_t eventResult;
			} ev;
			struct {
				uint8_t error;
				uint8_t reserved;
			} er;
		};
	}fmt;
};

struct _VCMConfig {
	const char* ip_addr;
	uint16_t portNum;
	bool srt_enable;
	uint8_t debug_level;
};


struct _VHLConfig {
  	const char* vhl_name;
  	const char* line;
  	const char* floor;
  	bool cam_ch0;
	bool cam_ch1;
	bool cam_ch2;
	bool cam_ch3;
	bool cam_ch0_rotate;
	bool cam_ch1_rotate;
	bool cam_ch2_rotate;
	bool cam_ch3_rotate;
	int recording_time;
	int event_storage_size;
	bool event_auto_remove;
};
#pragma pack(pop)

extern _VCMConfig vcmConf;
extern _VHLConfig vhlConf;

extern long getTick();
extern _SYSTEMTIME get_sys_time();
extern void myprintf( uint8_t _nloglevel, bool debug, const char* _szfmt, ... );
#define __E(flag, fmt, args...) 		do { myprintf( flag, MY_DEBUG, (char*)fmt, ##args ); } while(0)

#endif
