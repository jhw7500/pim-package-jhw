#!/bin/bash

mnt_state_=0
mnt_cnt_=0

while true; do
    case $mnt_state_ in
        0)
            if [ -d /sys/bus/mmc/devices/mmc0:*/block/mmcblk0/mmcblk0p1 ]; then
                mout_dev=`df | grep '/mnt/sdb' | awk '{print $1}'`
                if [ -z $mout_dev ]; then
                    if [ ! -d /mnt/sdb ]; then
                        mkdir -p /mnt/sdb
                    fi
                    mount /dev/mmcblk0p1 /mnt/sdb
                elif [ $mout_dev != "/dev/mmcblk0p1" ]; then
                    umount /mnt/sdb
                    mount /dev/mmcblk0p1 /mnt/sdb
                fi
                mnt_state_=1
                mnt_cnt_=0
            fi
        ;;
        1)
            if [ ! -d /sys/bus/mmc/devices/mmc0:*/block/mmcblk0/mmcblk0p1 ]; then
                mnt_cnt_=`expr $mnt_cnt_ + 1`
                if [ $mnt_cnt_ -ge 4 ]; then
                    umount /mnt/sdb
                    mnt_state_=0
                fi
            else
                mnt_cnt_=0
            fi
        ;;
    esac
    sleep 0.5
done
